/* SPDX-License-Identifier: GPL-2.0 */
/******************************************************************************
 *
 * Copyright(c) 2007 - 2011 Realtek Corporation. All rights reserved.
 *
 ******************************************************************************/
#ifndef __RTW_IOL_H_
#define __RTW_IOL_H_

#include <drv_types.h>

bool rtw_iol_applied(struct adapter *adapter);

#endif /* __RTW_IOL_H_ */
